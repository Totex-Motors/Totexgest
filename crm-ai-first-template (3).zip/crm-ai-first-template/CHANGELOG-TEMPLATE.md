# Template 2026.09.14

Inclui as melhorias desenvolvidas sobre o ZIP original: MCP OAuth e ferramentas, agentes com habilidades, playground opcional por contato, formulários e canais, campos, inbox unificado, integração social e métricas, consultas Meta Ads, correções de Realtime e isolamento.

Adaptações de distribuição: domínio por CRM_PUBLIC_URL, instalador com Node 22 e proteção contra recriação acidental, exemplos genéricos, documentação de MCP/OAuth, exclusão de arquivos privados e evidências de clientes.

A sequência histórica de migrations é preservada. Modelos e serviços externos não são patrocinados pelo pacote.

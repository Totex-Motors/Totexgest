# Uso na sua instalação

Use o domínio do seu CRM. Formulários publicados exibem seus links/embeds na interface. O MCP fica em /mcp após seguir PUBLICAR_E_CONECTAR_MCP.md. Gere seu QR Code a partir do link da própria instalação; não reutilize QR de outro ambiente.

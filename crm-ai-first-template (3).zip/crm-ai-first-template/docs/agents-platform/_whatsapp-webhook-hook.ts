/**
 * HISTÓRICO — não copiar para o CRM completo.
 *
 * O roteador WhatsApp V2 já está integrado e protegido em:
 *   supabase/functions/whatsapp-webhook/agent-platform.ts
 *
 * A implementação atual depende também de:
 *   supabase/functions/_shared/agent-whatsapp-send.ts
 *   supabase/functions/agent-runner/index.ts
 *   supabase/migrations/20260712000400_agent_whatsapp_v2_runtime.sql
 *
 * Manter este arquivo vazio evita que uma IA ou instalação manual substitua a
 * versão multi-tenant atual pelo snippet antigo, que usava uma flag global.
 */
export {};
